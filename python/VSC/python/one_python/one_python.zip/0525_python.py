# #1
# import turtle
# t = turtle.Turtle()
# t.shape("turtle")

# def square(length):
#     t.down()
#     for i in range(4):
#         t.forward(length)
#         t.left(90)
#     t.up()

# square(100)
# t.forward(120)
# square(100)
# t.forward(120)
# square(100)

# turtle.done()

# #1-1
# def input_square_num():
#     inputNum = int(input("한변의 값을 입력하시오 : "))
#     return inputNum

# square(input_square_num())
# t.forward(120)
# square(input_square_num())
# t.forward(120)
# square(input_square_num())
    
# turtle.done()

# #2
# def menu():
#     print("1. 섭씨 온도 -> 화씨 온도")
#     print("2. 화씨 온도 -> 섭씨 온도")
#     print("3. 종료")
#     selection = int(input("메뉴를 입력하시오 : "))
#     return selection

# def ctof(c):
#     temp = c * 9.0 / 5.0 + 32
#     return temp

# def ftoc(f):
#     temp = (f - 32.0) * 5.0 / 9.0
#     return temp

# def input_f():
#     f = float(input("화씨 온도를 입력하시오 : "))
#     return f

# def input_c():
#     c = float(input("섭씨 온도를 입력하시오 : "))
#     return c

# def main():
#     while True:
#         index = menu()
#         if index == 1:
#             t = input_c()
#             t2 = ctof(t)
#             print("화씨 온도 = {}\n".format(t2))
#         elif index == 2:
#             t = input_f()
#             t2 = ftoc(t)
#             print("섭씨 온도 = {}\n".format(t2))
#         else:
#             break

# main()

#3
gx = 100

def func1():
    print("func1() : ", gx)

def func2():
    gx = 200
    print("func2() : ", gx)

func1()
func2()
print("외부 : ", gx)