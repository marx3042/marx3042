#1
def menu_print():
    print("1번을 입력하면 : 한변의 길이를 입력받아 정사각형의 넓이를 구함")
    print("2번을 입력하면 : 반지름 길이를 입력받아 원의 넓이를 구함 ")
    print("종료하려면 '0'을 입력하세요")

def menu_chice():
    num = int(input("번호를 선택하시오 : "))
    return num

def input_one_num():
    num1 = float(input("정사각형의 한변의 길이는 : "))
    return num1
def input_two_num():
    num1 = int(input("원의 반지름의 길이는? : "))
    return num1

def square_area(a):
    result = a * a
    return result

def circle_area(b):
    result = b ** 2 * 3.14
    return result

menu_print()
while True:
    menu = menu_chice()
    
    if menu == 1:
        line = input_one_num()
        print("사각형의 넓이는 %.3f입니다."%square_area(line))
    elif menu == 2:
        r = input_two_num()
        print("원의 넓이는 %d입니다."%circle_area(r))
    elif menu == 0:
        break
    else:
        continue

#2
lst = []
while True:
    num = int(input("정수를 입력하시오 : "))
    if num == 0:
        break

    lst.append(num)
result = sum(lst) / len(lst)
print("평균은 %.1f"%result)


#3
import random
lst = []
result = []

for i in range(5):
    aa = random.randint(1, 50)
    lst.append(aa)

for i in lst:
    if i % 3 == 0:
        result.append(i)
print(f"생성된 난수는 {lst}")
print("5개의 난수 중 3의 배수는 {}".format(result))