#1
x = int(input("x : "))
y = int(input("y : "))
print("두수의 합 : {}".format(x + y))
print("두수의 차 : {}".format(x - y))
print("두수의 곱 : {}".format(x * y))
print("두수의 평균 : {:.1f}".format((x + y) / 2))
print("큰수 : {}".format(max(x, y)))
print("작은수 : {}".format(min(x, y)))

#2
cookie = int(input('과자의 개수 : '))
divide = int(input("한 사람당 나누어주는 과자의 개수 : "))
q = cookie // divide
r = cookie % divide

print("최대 {}명에게 나누어줄 수 있습니다.".format(q))
print("남은 과자는 {}개입니다.".format(r))

#4
side1 = int(input("삼각형의 첫 번째 변의 길이 : "))
side2 = int(input("삼각형의 두 번째 변의 길이 : "))
side3 = (side1 + side2) - 1
print("삼각형의 나머지 변의 최대 길이 = {}".format(side3))

#5
hour = int(input("시간을 입력하시오 : "))
minute = int(input("분을 입력하시오 : "))
second = (hour * 3600) + (minute * 60)
print("{0}시간 {1}분은 {2}초입니다.".format(hour, minute, second))

#10
num = int(input("정수 = "))

num1000 = num // 1000
num -= num1000 * 1000

num100 = num // 100
num -= num100 * 100

num10 = num // 10

num1 = num % 10
result = num1000 + num100 + num10 + num1
print(result)

#11
a = 10
b = 20

print("바꾸기 전 : a = {} b = {}".format(a, b))
a, b = b, a
print("바꾸기 후 : a = {} b = {}".format(a, b))