#1
x = int(input("정수를 입력하시오 : "))
y = int(input("정수를 입력하시오 : "))

if x % y == 0:
    print("약수입니다.")
else:
    print("나누어 떨어지지 않습니다.")

#2
num = int(input("정수를 입력하시오 : "))

if num > 0:
    print("양수")
elif num == 0:
    print(0)
else:
    print("음수")

#3
a = input("문자를 입력하시오 : ")

if a == "R" or a == "r":
    print("Rectangle")
elif a == "T" or a == "t":
    print("Triangle")
elif a == "C" or a == "c":
    print("Circle")
else:
    print("Unknown")

#4
x, y, z = eval(input("3개의 정수를 입력하시오 : "))
result = 0

if x > y:
    if y > z:
        result = z
    else:
        result = y
else:
    if x > z:
        result = z
    else:
        result = x
print("제일 작은 정수는 %d입니다."%result)

#5
height = float(input("키를 입력하시오 : "))
age = int(input("나이를 입력하시오 : "))

if height >= 140 and age >= 10:
    print("타도 좋습니다.")
else:
    print("죄송합니다.")
    