#1
i = 1
sum = 0

while i <= 10:
    sum += i
    i += 1

print("while문 합계는 : ", sum)

#############
sum = 0
for i in range(1, 11):
    sum += i

print("for문 합계는 : ", sum)

sum = 0
j = 1
for i in range(2, 12):
    sum += j
    j += 1

print("누적 합 : ", sum)

#2
total = 0
answer = "yes"

while answer == "yes":
    number = int(input("숫자를 입력하시오 : "))
    total += number

    answer = input("계속?(yes/no): ")

print("합계는 : ", total)

###########
total = 0
inputNum = None

while not inputNum == 0:
    inputNum = int(input("숫자를 입력하시오 : "))
    total += inputNum

print("누적 합은 : ", total)

#3
import random

tries = 0
guess = 0
answer = random.randint(1, 100)

print("1부터 100 사이의 숫자를 맞추시오")

while not guess == answer:
    guess = int(input("숫자를 입력하시오 : "))
    tries += 1

    if guess < answer:
        print("너무 낮음!")
    elif guess > answer:
        print("너무 높음!")

if guess == answer:
    print("축하합니다. 시도 횟수 = ", tries)
else :
    print("정답은", answer)

########
tries = 0
guess = 0
answer = random.randint(1, 100)

print("1부터 100 사이의 숫자를 맞추시오")

while not guess == answer:
    guess = int(input("숫자를 입력하시오 : "))
    if guess == 0:
        break

    tries += 1

    if guess < answer:
        print("너무 낮음!")
    elif guess > answer:
        print("너무 높음!")

if guess == answer:
    print("축하합니다. 시도 횟수 = ", tries)
    print("정답은 ", answer)
else :
    print("정답은", answer)

#4
import random

flag = True

while flag:
    x = random.randint(1, 100)
    y = random.randint(1, 100)
    answer = int(input("{} + {} = ".format(x, y)))

    if answer == x + y:
        print("잘했어요!!")
    else:
        print("틀렸어요. 하지만 다음번에는 잘할 수 있죠?")
        flag = False

########
while True:
    x = random.randint(1, 100)
    y = random.randint(1, 100)
    answer = int(input("{} + {} = ".format(x, y)))

    if answer == x + y:
        print("잘했어요!!")
    else:
        print("틀렸어요. 하지만 다음번에는 잘할 수 있죠?")
        break

#5
for y in range(1, 6):
    for x in range(y):
        print("*", end = "")
    print()

##########
for y in range(5, 0, -1):
    for x in range(y):
        print("*", end = "")
    print()

