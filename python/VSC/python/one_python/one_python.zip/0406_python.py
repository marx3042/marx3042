#1
price = int(input("가격을 입력하시오 : "))
card = input("카드 종류를 입력하시오 : ")
shipping_cost = 0

if price > 20000 and card == "python":
    shipping_cost = 0
else:
    shipping_cost = 3000

print("배송료는 {}원 입니다.".format(shipping_cost))

#2
x = int(input("첫 번째 수 = "))
y = int(input("두 번째 수 = "))

if x > y:
    max_value = x
    min_value = y
else:
    max_value = y
    min_value = x

print("큰 수는 %d이고 작은 수는 %d이다."%(max_value, min_value))

#3
import random

x = random.randint(1, 100)
y = random.randint(1, 100)
answer = int(input("{} + {} = ".format(x, y)))

if answer == (x + y):
    flag = True
else:
    flag = False

print(flag)

#4
country = input("배송지(현재는 korea와 us만 가능) : ")
price = int(input("상품의 가격 : "))

shipping_cost = 0

if country == "korea":
    if not(price >= 20000):
        shipping_cost = 3000
else:
    if not(price >= 100000):
        shipping_cost = 8000

print("배송비 = ", shipping_cost)

#5
score = int(input("성적을 입력하시오 : "))

if score >= 90:
    result = "A"
elif score >= 80:
    result = "B"
elif score >= 70:
    result = "C"
elif score >= 60:
    result = "D"
else:
    result = "F"

print("학점", result)