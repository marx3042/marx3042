#1
scale = float(input("리히터 규모를 입력하시오 : "))

if scale >= 8.0:
    print("대부분의 구조물이 파괴됩니다.")
elif scale >= 7.0:
    print("지표면의 균열이 발생합니다.")
elif scale >= 4.0:
    print("빈약한 건물에 큰 피해가 있습니다.")
elif scale >= 2.0:
    print("물건들이 흔들리거나 떨어집니다.")
else:
    print("지진계에 의해서만 탐지 가능합니다.")

#2
import turtle
t = turtle.Turtle()
t.shape("turtle")

s = turtle.textinput("", "도형을 입력하시오 : ")

if s == "사각형":
    w = int(turtle.textinput("", "가로 : "))
    h = int(turtle.textinput("", "세로 : "))
    t.forward(w)
    t.left(90)
    t.forward(h)
    t.left(90)
    t.forward(w)
    t.left(90)
    t.forward(h)
elif s == "삼각형":
    w = int(turtle.textinput("", "한 변 : "))
    t.forward(w)
    t.left(120)
    t.forward(w)
    t.left(120)
    t.forward(w)
elif s == "원":
    w = int(turtle.textinput("", "반지름 : "))
    t.circle(w, 360)

turtle.done()