#1
for i in range(0, 10, 2):
    print(i)

i = 0
while i < 10:
    print(i)
    i += 2

#2
sum = 0
for i in range(10, 0, -1):
    sum += i
print(sum)

sumW = 0
i = 10
while i > 0:
    sumW += i
    i -= 1

print(sumW)

#3
i = 0
while i <= 10:
    print("Hi!!! ")
    i += 1

for i in range(0, 11):
    print("Hi!!! ")

i = 1
while i < 10:
    if i % 2 == 0:
        print(i)
    i += 1

for i in range(1, 10):
    if i % 2 == 0:
        print(i)

#4
def get_area(radius):
    area = 3.14 * (radius ** 2)
    return area

result = get_area(3)
print("반지름이 3인 원의 면적 = ", result)

#5
def get_area(radius):
    area = 3.14 * (radius ** 2)
    return area

print("반지름이 3인 원의 면적 = ", get_area(3))
print("반지름이 20인 원의 면적 = ", get_area(20))

#6
def get_input():
    return 2, 3

x, y = get_input()