#1
def main():
    print("20cm 피자 2개의 면적 : ", get_area(20) + get_area(20))
    print("30cm 피자 1개의 면적 : ", get_area(30))

def get_area(radius):
    if radius > 0:
        area = 3.14 * radius ** 2
    else:
        area = 0
    
    return area

main()

#1-1
def input_radius():
    inputNum = int(input("반지름을 입력하시오 : "))

    return inputNum

def get_area(radius):
    if radius > 0:
        area = 3.14 * radius ** 2
    else:
        area = 0
    
    return area

def print_area(area):   
    print("원의 넓이는 : ", area)

radius = input_radius()
print_area(get_area(radius))

#2
def func():
    x = 100
    print(x)

x = 10
func()
print(x)