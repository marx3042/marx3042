#1
for i in range(1, 26):
    print(i * 2, end = " ")
print()

#2
listNum = [11, 22, 23, 99, 81, 93, 35]
sum = 0

for i in range(len(listNum)):
    sum += listNum[i]

print("정수들의 합은 : ", sum)

#3
number = int(input("정수를 입력하시오 : "))
i = 1

print("약수 : ", end = "")
while not i > number:
    if number % i == 0:
        print(i, end = " ")
    i += 1

print()

#4
number = int(input("정수를 입력하시오 : "))

for y in range(1, number + 1):
    for x in range(1, y + 1):
        print(x, end = "")
    print()

#5
print("마일\t", "킬로미터")

for i in range(1, 11):
    print("%d\t%.3f"%(i, i * 1.609))