#1
x = int(input("피젯수:"))
y = int(input("젯수:"))

q = x // y
r = x % y

print("{0}을 {1}로 나눈 몫 = {2}".format(x, y, q))
print("{0}을 {1}로 나눈 나머지 = {2}".format(x, y, r))

print("%d을 %d로 나눈 몫 = %d"%(x, y, q))
print("%d을 %d로 나눈 나머지 = %d"%(x, y, r))

#2
x = 1000
x += 2
print("x는 %d입니다."%x)
x -= 2
print("x는 %d입니다."%x)

#3
total_sales = 0
milk_count = int(input("판매된 우유의 개수 : "))
cola_count = int(input("판매된 콜라의 개수 : "))
krice_count = int(input("판매된 김밥의 개수 : "))

total_sales += milk_count * 2000
total_sales += cola_count * 3000
total_sales += krice_count * 3500

print("\n오늘 총 매출은 {}원 입니다.".format(total_sales))

#4
s1 = "Audrey Hepburn"
s2 = "Grace Kelly"
print(s1 < s2)

#5
score1 = int(input("국어 성적 : "))
score2 = int(input("수학 성적 : "))
score3 = int(input("영어 성적 : "))
avg = (score1 + score2 + score3) / 3

print("\n평균 성적은 {:.2f}점 입니다.".format(avg))
print("\n평균 성적은 %.2f점 입니다."%avg)

#6
ans = int(input("2 + 5 = "))
print(ans == 2 + 5)

ans = int(input("7 - 6 = "))
print(ans == 7 - 6)

ans = int(input("2 ** 3 = "))
print(ans == 2 ** 3)

ans = int(input("3.0 / 1.5 = "))
print(ans == 3.0 / 1.5)

#7
score = 0
ans = input("가장 쉬운 프로그래밍 언어는? : ")
check = (ans == "파이썬")
print(check)
score += int(check)

ans = input("거듭제곱을 계싼하는 연산자는? : ")
check = (ans == "**")
print(check)
score += int(check)

ans = input("파이썬에서 출력시에 사용하는 함수이름은? : ")
check = (ans == "print")
print(check)
score += int(check)
print("점수 = {}".format(score))

#8
price = int(input("상품의 가격 : "))

if price > 20000:
    shipping_cost = 0
else :
    shipping_cost = 3000

print("배송비 = ", shipping_cost)