# #
# alist = []
# sum = 0

# for i in range(5):
#     i = int(input("정수를 입력하시오 : "))
#     alist.append(i)

# for i in alist:
#     sum += i

# avg = sum/len(alist)
# print("평균 =", avg)

# #
# i = 0
# while i < 5:
#     num = int(input("정수입력:"))
#     alist.append(num)
#     i += 1

# #
# import random

# alist = []
# sum = 0
# for i in range(4):
#     num = random.randint(1, 100)
#     alist.append(num)
#     sum += alist[i]
#     print(f"{i+1} 번째 숫자 {alist[i]}")

# print(sum)

# #
# alist = [90, 80, 20, 60, 70]
# print(min(alist))
# alist.sort()
# print(alist[0])

# #
# def menu():
#     print("1번을 입력하면 : 섭씨 온도를 화씨온도로")
#     print("종료하려면 1번을 제외한 값을 입력")
#     choice = int(input("번호 선택 : "))
#     return choice

# def input_c():
#     c = float(input("섭씨 온도를 입력하세요 : "))
#     return c

# def ctof(c):
#     temp = c * 9.0 / 5.0 + 32
#     return temp

# while True:
#     index = menu()
#     if not index == 1:
#         break

#     t = input_c()
#     t2 = ctof(t)
#     print("화씨 온도는 %d"%t2)

# #
# while True:
#     print("1번을 입력하면 : 섭씨 온도를 화씨 온도로")
#     print("종료하려면 1번을 제외한 값을 입력하세요")
#     choice = int(input("번호 선택 : "))
#     if not choice == 1:
#         break
    
#     c = float(input("섭씨 온도를 입력하세요 : "))
#     f = c * 9.0 / 5.0 + 32
#     print("화씨 온도는 %d"%f)

# #
# from test import *
# func1()
# func2()
# func3()

#
ary1 = []
ary2 = []
ary1 = list(int, input("정수값 4개 입력 : ").split())

for i in range(3, -1, -1):
    ary2.append(i)
print(ary2)