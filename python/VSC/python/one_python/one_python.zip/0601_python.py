#1
temps = [28,31,33,35,27,26,25]

if 33 in temps:
    print("리스트에 33이 있음!")

temps = [28,31,33,35,27,26,25]

if 99 not in temps:
    print("리스트에 99가 없음!")

#2
fruits = ["apple", "banana", "grape"]
fruits.insert(1, "cherry")
print(fruits)

#3
fruits = ["apple", "banana", "grape"]
item = fruits.pop(0)
print(fruits)

fruits = ["apple", "banana", "grape"]
fruits.remove("banana")
print(fruits)

#4
list1 = [1,2, 3, 4, 15, 99]

list1.sort()
print("두 번째로 큰 수 =", list1[-2])

list1 = [1,2, 3, 4, 15, 99]

list1.remove(max(list1))
print("두 번째로 큰 수 =", max(list1))

#5
STUDENTS = 5
lst = []
count = 0

for i in range(STUDENTS):
    value = int(input("성적을 입력하세요 : "))
    lst.append(value)

print("\n성적 평균 :", sum(lst) / len(lst))
print("최대점수 =", max(lst))
print("최소점수 =", min(lst))

for score in lst:
    if score >= 80:
        count += 1
print("80점 이상 =", count)

#5-1
STUDENTS = 5
lst = []
count = 0

def input_score():
    for i in range(STUDENTS):
        value = int(input("성적을 입력하세요 : "))
        lst.append(value)

def print_score():
    print("\n성적 평균 :", sum(lst) / len(lst))
    print("최대점수 =", max(lst))
    print("최소점수 =", min(lst))

def calc_count(lst):
    global count

    for score in lst:
        if score >= 80:
            count += 1
    print("80점 이상 =", count)

input_score()
print_score()
calc_count(lst)

#6
lst = [1, 2, 3, 4, 5, 6, 7, 8]
lst[0:3] = ['white', 'blue', 'red']
print(lst)

lst = [1, 2, 3, 4, 5, 6, 7, 8]
lst[::2] = [99, 99, 99, 99]
print(lst)

lst = [1, 2, 3, 4, 5, 6, 7, 8]
lst[:] = []
print(lst)

#7
numbers = list(range(1, 11))
print(numbers[-1::-2])

del numbers[1:]
print(numbers)