import numpy as np
import cv2

# 1)
bag_org = cv2.imread('Data\bag.png', cv2.IMREAD_COLOR)

bag_org_rev_c = bag_org[:, ::-1] # 좌우 반전 
bag_org_rev_r = bag_org[::-1, :] # 상하 반전

cv2.imshow('bag_org_rev_c', bag_org_rev_c)
cv2.imshow('bag_org_rev_r', bag_org_rev_r)


#2)
global img1, img2

def on_change_weight(x):
    weight = x / 100
    img_merged = cv2.addWeighted(img1, 1-weight, img2, weight, 0)
    cv2.imshow('Display', img_merged)

cv2.namedWindow('Display')
cv2.createTrackbar('weight', 'Display', 0, 100, on_change_weight)

img1 = cv2.imread('bag.png')
img2 = cv2.imread('ape.png')
print(img1.shape);  print(img2.shape)

img1 = cv2.resize(img1, (200, 300))
img2 = cv2.resize(img2, (200, 300))

cv2.imshow('Display', img1)


cv2.waitKey(0)
cv2.destroyAllWindows()

#3)

img = cv2.imread('Data\bag.png', cv2.IMREAD_GRAYSCALE)

img_edge1_5 = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY,  blockSize=9, C=5)
cv2.imshow('edge_C=5', img_edge1_5)