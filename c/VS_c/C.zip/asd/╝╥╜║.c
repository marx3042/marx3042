#include <stdio.h>
#include <stdlib.h>


int function(int a) {
	int tot=1;
	if (a == 1) return tot;

	tot = a * function(a - 1);
	
	return tot;
}
	

int main (void) {
	int a;
	int b = scanf_s("%d",&a);
	printf("%d", a);

	return 0;
}
