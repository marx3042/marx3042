#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
	int data;
	struct Node *nextNode;
}Node;

Node *head;
void choiceNode(Node* head, int c, int value) {
	head=malloc(sizeof(Node));
	head->nextNode=NULL;

	Node *new = malloc(sizeof(Node));
	new->data=value;
	Node *cur=head;
	for (int i = 0; i < c; i++) {
		cur=cur->nextNode;
	}
	new->nextNode=cur->nextNode;
	cur->nextNode=new;
}

void Insert(Node *head, int choice, int value) {
	head=malloc(sizeof(Node));
	head->nextNode=NULL;
	
	Node *new = malloc(sizeof(Node));
	new->data=value;

	if (choice == 1) {
		new->nextNode=head->nextNode;
		head->nextNode=new;
	}
	else {
		Node *end=head;
		while (end != NULL) {
			end=end->nextNode;
		}
		end->nextNode=new;
		new->nextNode=NULL;
		
		return end;
	}
}

void main () {
	int ott=0;
	int value;
	int choiceLocation;

	while (ott != 5) {
		printf("1 �Ǿ�\n2 �ǵ�\n3 ����\n5 ����\n========\n");
		scanf_s("%d",&ott);
		printf("���ο� ��\n");
		scanf_s("%d",&value);
		if (ott == 1 || ott == 2) {
			Insert(head,ott,value);
		}
		else if (ott==3) {
		printf("���° �ڿ� ������\n");
		scanf_s("%d",&choiceLocation);
			choiceNode(head, choiceLocation,value);
		}
	}
	Node *cur = head;
	while (cur->nextNode != NULL) {
		cur=cur->nextNode;
		printf("%d ", cur->data);
	}
}