#include <stdio.h>

int main(void) {
	int arNum[100];
	int count=0;
	for (int i = 0; i < 100; i++) {
		scanf_s("%d",&arNum[i]);
		if (arNum[i] == 0) {
			break;
		}
		count++;
	}
	for (int i = count-1; i >= 0; i--) {
		printf("%d ",arNum[i]);
	}
	


	return 0;
}