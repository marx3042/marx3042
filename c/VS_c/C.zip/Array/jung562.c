#include <stdio.h>

int main(void) {

	float arNum[6];
	float sum=0.0;
	float avg=0.0;
	for (int i = 0; i < 6; i++) {
		scanf_s("%f",&arNum[i]);
		sum+=arNum[i];
	}
	avg = sum/6;
	printf("%.1f",avg);

	return 0;
}