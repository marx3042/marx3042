#include <stdio.h>

int main(void) {

	float arNum[6] = { 85.6, 79.5, 83.1, 80.0, 78.2, 75.0 };
	int num1,num2;
	scanf_s("%d%d",&num1,&num2);
	printf("%.1f",arNum[num1-1]+arNum[num2-1]);

	return 0;
}