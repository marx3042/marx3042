#include <stdio.h>

int main(void) {

	int arNum[2][3];
	int arNum2[2][3];
	int arNum3[2][3];

	printf("first array\n");
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 3; j++) {
			scanf_s("%d",&arNum[i][j]);
		}
	}
	printf("second array\n");
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 3; j++) {
			scanf_s("%d", &arNum2[i][j]);
		}
	}
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 3; j++) {
			arNum3[i][j] = arNum[i][j]*arNum2[i][j];
		}
	}
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 3; j++) {
			printf("%d ", arNum3[i][j]);
		}
		printf("\n");
	}
	return 0;
}