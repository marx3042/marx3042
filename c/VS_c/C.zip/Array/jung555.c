#include <stdio.h>

int main(void) {
	char c[10];

	for (int i = 0; i < 10; i++) {
		scanf_s(" %c",&c[i]);
	}
	for (int i = 0; i < 10; i++) {
		printf("%c",c[i]);
	}
	

	return 0;
}