#include <stdio.h>

int main(void) {
	int inputNum;
	int arNum[20];
	int number;

	scanf_s("%d", &inputNum);
	for (int i = 0; i < inputNum; i++) {
		scanf_s("%d",&arNum[i]);
	}

	for (int i = 0; i < inputNum - 1; i++) {
		for (int j = 0; j < inputNum - 1; i++) {
			if(arNum[j]<arNum[j+1]){
				number = arNum[j+1];
				arNum[j+1] = arNum[j];
				arNum[j] = number;
			}
		}
	}
	for (int i = 0; i < inputNum; i++) {
		printf("%d\n",arNum[i]);
	}
	
	
	

	return 0;
}