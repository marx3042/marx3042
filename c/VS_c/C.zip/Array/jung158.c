#include <stdio.h>

int main(void) {

	int arNum[100];
	int count=0;
	int odd,even;
	for (int i = 0; i < 100; i++) {
		scanf_s("%d",&arNum[i]);
		if (arNum[i] == 0) {
			break;
		}
		count++;
		
	}
	printf("%d\n",count);
	for (int i = 0; i < count; i++) {
		if (arNum[i] % 2 == 1) {
			odd=arNum[i] * 2;
			printf("%d ", odd);
		}
		else {
			even = arNum[i] / 2;
			printf("%d ", even);
		}
		
	}

	return 0;
}