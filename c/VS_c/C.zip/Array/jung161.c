#include <stdio.h>

int main(void) {

	int count[11];
	int a,b;

	for (int i = 0; i < 11  ; i++) {
		count[i]=0;
	}

	while (1) {
		scanf_s("%d",&a);
		if (a == 0) {
			break;
		}
		b=a/10;
		if (a < 10) {
			b=0;
		}
		count[b]++;
	}
	for (int i = 10; i >= 0; i--) {
		if (count[i] != 0) {
			printf("%d : %d person\n",(i*10),count[i]);
		}
	}
	return 0;
}