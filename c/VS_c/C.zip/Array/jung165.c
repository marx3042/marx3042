#include <stdio.h>

int main(void) {
	
	int arNum[5][5];

	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			arNum[i][j] = 0;
		}
	}

	for (int i = 0; i < 5; i += 2) {
		arNum[0][i] = 1;
	}

	for (int i = 1; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			if(j-1<0){
				arNum[i][j] = arNum[i - 1][j + 1];
			}
			else if(j+1>4){
				arNum[i][j] = arNum[i - 1][j - 1];
			}
			else {
				arNum[i][j] = arNum[i - 1][j - 1] + arNum[i - 1][j + 1];
			}
		}
	}
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			printf("%d ",arNum[i][j]);
		}
		printf("\n");
	}

	return 0;
}