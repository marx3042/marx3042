#include <stdio.h>

int main(void) {
	
	int arNum[10][10];
	int num;
	int a=3;
	scanf_s("%d",&num);

	for (int i = 0; i < 10; i++) {
		for (int j = 0 ;j < 10; j++) {
			arNum[i][j]=1;
		}
	}
	for (int i = 2; i < num; i++) {
		for (int j = 1; j < a; j++) {
			if (j > 0 && j < a-1) {
				arNum[i][j] = arNum[i - 1][j - 1] + arNum[i - 1][j];
			}
		}
		a++;
		if (a > num) {
			break;
		}
	}
	a=num;
	for (int i = num-1; i >= 0; i--) {
		for (int j = 0; j < a; j++) {
			printf("%d ",arNum[i][j]);
		}
		printf("\n");
		a--;
	}


	
	return 0;
}