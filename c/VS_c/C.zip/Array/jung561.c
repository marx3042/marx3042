#include <stdio.h>

int main(void) {

	int maxUp=10001;
	int minDown=0;
	int arNum[10];
	for (int i = 0; i < 10; i++) {
		scanf_s("%d",&arNum[i]);
		if (arNum[i] < 100) {
			if (arNum[i] > minDown) {
				minDown=arNum[i];
			}
		}
		else {
			if (arNum[i]<maxUp) {
				maxUp = arNum[i];
			}
		}
	}
	if (maxUp == 10001) {
		maxUp=100;
	}
	if (minDown == 0) {
		minDown=100;
	}
	printf("%d %d",maxUp,minDown);

	return 0;
}