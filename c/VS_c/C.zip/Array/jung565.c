#include <stdio.h>

int main(void) {

	int arNum[100];
	int a;
	int b;
	for (int i = 0; i < 100; i++) {
		arNum[i] = 0;
	}

	while (1) {
		scanf_s("%d",&a);
		if (a == 0) {
			break;
		}
		b=a/10;
		arNum[b]++;
	}
	for (int i = 0; i < 100; i++) {
		if (arNum[i] != 0) {
			printf("%d : %d\n",i,arNum[i]);
		}
	}

	return 0;
}