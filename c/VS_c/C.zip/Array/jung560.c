#include <stdio.h>

int main(void) {

	int min=1001;
	int arNum[10];

	for (int i = 0; i < 10; i++) {
		scanf_s("%d",&arNum[i]);
		if (min > arNum[i]) {
			min=arNum[i];
		}
	}
	printf("%d",min);

	return 0;
}