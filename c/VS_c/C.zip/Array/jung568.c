#include <stdio.h>

int main(void) {
	
	int arNum[2][4];
	int arNum2[2][4];
	
	printf("first array");
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 4; j++) {
			scanf_s("%d",&arNum[i][j]);
		}
		printf("\n");
	}
	printf("second array");
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 4; j++) {
			scanf_s("%d", &arNum2[i][j]);
		}
		printf("\n");
	}

	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < 4; j++) {
			printf("%d ",arNum[i][j]*arNum2[i][j]);
		}
		printf("\n");
	}


	return 0;
}