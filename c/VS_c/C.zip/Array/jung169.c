#include <stdio.h>

int main(void) {
	
	char arNum[3][5];
	int a;
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 5; j++) {
			scanf_s(" %c", &arNum[i][j]);
		}
	}
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 5; j++) {
			a = (int)arNum[i][j]+32;
			printf("%c ", (char)a);
		}
		printf("\n");
	}

	


	return 0;
}