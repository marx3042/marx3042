#include <stdio.h>

int main(void) {
	int arNum[10];

	for (int i = 0; i < 10; i++) {
		arNum[i] = i+1;
	}
	for (int i = 0; i < 10; i++) {
		printf("%d ", arNum[i]);
	}


	return 0;
}