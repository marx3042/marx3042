#include <stdio.h>

int main(void) {

	int a,b;
	int arNum[10];

	scanf_s("%d%d",&a,&b);

	arNum[0]=a;
	arNum[1]=b;

	for (int i = 2; i < 10; i++) {
		arNum[i]=(arNum[i-1]+arNum[i-2])%10;
	}
	for (int i = 0; i < 10; i++) {
		printf("%d ",arNum[i]);
	}

	return 0;
}