#include <stdio.h>

int main(void) {

	int arNum[4][2];
	int z;
	int avg;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 2; j++) {
			scanf_s("%d", &arNum[i][j]);
		}
	}
	for (int i = 0; i < 4; i++) {
		z = 0;
		avg = 0;
		for (int j = 0; j < 2; j++) {
			z += arNum[i][j];
		}
		avg =z / 2;
		printf("%d ", avg);
	}
	printf("\n");
	
	for (int i = 0; i < 2; i++) {
		z=0;
		avg = 0;
		for (int j = 0; j < 4; j++) {
			z += arNum[j][i];
		}	
		avg = z / 4;
		printf("%d ", avg);
	}
	printf("\n");
	avg = 0;
	z=0;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 2; j++) {
			z +=arNum[i][j];
		}
	}
	avg = z/8;
	printf("%d",avg);
	return 0;
}