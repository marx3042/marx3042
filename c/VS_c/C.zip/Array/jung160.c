#include <stdio.h>

int main(void) {

	int arNum[6];
	int a;
	
	for (int i = 0; i < 6; i++) {
		arNum[i]=0;
	}
	for (int i = 0; i < 10; i++) {
		scanf_s("%d",&a);
		arNum[a-1]++;
	}
	for (int i = 0; i < 6; i++) {
		printf("%d : %d",i+1,arNum[i]);
	}

	return 0;
}