#include <stdio.h>

int main(void) {

	char c[6] = { 'J', 'U', 'N', 'G', 'O', 'L' };
	char input;
	int count=1;
	scanf_s(" %c", &input);
	for (int i = 0; i < 6; i++) {
		if (c[i] == input) {
			printf("%d",i);
			count = 0;
		}
	}
	if (count == 1) {
		
		printf("none");
	}

	return 0;
}