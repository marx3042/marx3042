#include <stdio.h>

int main(void) {

	int arNum[4][3];
	int sum;
	for (int i = 0; i < 4; i++) {
		printf("%dclass? ",i+1);
		for (int j = 0; j < 3; j++) {
			scanf_s("%d",&arNum[i][j]);
		}
	}
	for (int i = 0; i < 4; i++) {
		sum=0;
		for (int j = 0; j < 3; j++) {
			sum+=arNum[i][j];
		}
		printf("%dclass : %d",i+1,sum);
		printf("\n");
	}


	return 0;
}