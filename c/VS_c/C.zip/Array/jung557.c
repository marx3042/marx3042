#include <stdio.h>

int main(void) {
	char c[10];
	
	for (int i = 0; i < 10; i++) {
		scanf_s(" %c",&c[i]);
		if (i + 1 == 1 || i + 1 == 4 || i + 1 == 7) {
			printf("%c ",c[i]);
		}
	}
	


	return 0;
}