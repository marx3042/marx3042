#include <stdio.h>

int main(void) {

	char a;
	scanf_s("%c",&a);
	for (int i = 0; i < 20; i++) {
		printf("%c",a);
	}

	return 0;
}