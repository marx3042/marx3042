#include <stdio.h>

int main(void) {
	int a=2;
	int b=0;
	for (int i = 0; i < 5; i++) {
		b=a;
		for (int j = 0; j < 5; j++) {
			printf("%d ",b++);
		}
		a++;
		printf("\n");
	}

	return 0;
}