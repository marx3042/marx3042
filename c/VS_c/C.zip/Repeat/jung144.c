#include <stdio.h>

int main(void) {
	int num;
	int a = 0;
	scanf_s("%d", &num);
	a = num*2-2;
	for (int i = 0; i < (num * 2) - 1; i += 2) {
		for (int j = a; j > 0; j--) {
			printf(" ");
		}
		for (int j = 0; j <= i; j++) {
			printf("*");
		}
		printf("\n");
		a-=2;
	}

	return 0;
}