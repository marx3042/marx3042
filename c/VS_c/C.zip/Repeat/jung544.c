#include <stdio.h>

int main(void) {
	int a;
	int sum=0;
	scanf_s("%d",&a);
	for (int i = a; i <= 100; i++) {
		sum+=i;
	}
	printf("%d",sum);
	return 0;
}