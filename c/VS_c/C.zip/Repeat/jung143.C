#include <stdio.h>



int main(void) {
	int num;
	int down;
	int a = 0;
	scanf_s("%d", &num);
	down = num-2;

	for (int i = (num * 2) - 1; i > 0; i -= 2) {
		for (int j = 0; j < a; j++) {
			printf(" ");
		}
		for (int j = 0; j < i; j++) {
			printf("*");
		}
		printf("\n");
		a++;
	}
	for (int i = 3; i <= (num * 2) - 1; i += 2){
		for (int j = down; j > 0; j--) {
			printf(" ");
		}
		for (int j = 0; j < i; j++) {
			printf("*");
		}
		printf("\n");
		down--;
	}
	
	
	


	return 0;
}