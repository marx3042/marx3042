#include <stdio.h>

int main(void) {

	int a,num;
	int sum=0;
	float avg=0;
	scanf_s("%d",&a);
	for (int i = 0; i < a; i++) {
		scanf("%d",&num);
		sum+=num;
	}
	avg = (float)sum/a;

	if (avg >= 80) {
		printf("avg : %.1f\npass", avg);
	}
	else {
		printf("avg : %.1f\nfail", avg);
	}
	
	return 0;
}