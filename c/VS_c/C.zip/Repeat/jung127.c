#include <stdio.h>

int main(void) {

	int a;
	int sum=0;
	float avg=0;
	int count=0;

	while (1) {	
		scanf_s("%d", &a);
		if (a < 0 || a>100) {
			break;
		}
		
		sum += a;
		count++;
	}
	avg = (float)sum/count;
	printf("sum = %d\navg = %.1f",sum,avg);
	



	return 0;
}