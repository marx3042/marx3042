#include <stdio.h>

int main(void) {
	int a=10;
	for (int i = 0; i < 11; i++) {
		printf("%d ",a++);
	}
	return 0;
}