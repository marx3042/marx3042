#include <stdio.h>

int main(void) {

	int a;
	int odd = 0;
	int even = 0;
	for (int i = 0; i < 10; i++) {
		scanf_s("%d", &a);
		if (a % 2 != 0) {
			odd++;
		}
		else {
			even++;
		}
	}
		

	printf("even : %d\nodd : %d", even, odd);

	return 0;
}