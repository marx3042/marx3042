#include <stdio.h>

int main(void) {
	int a;
	int num;
	int sum=0;
	float avg =0;
	scanf_s("%d",&a);
	for (int i = 0; i < a; i++) {
		scanf_s("%d", &num);
		sum+=num;
	}
	avg=(float)sum/a;
	printf("%.2f",avg);
	return 0;
}