#include <stdio.h>

int main(void) {
	int a,b;
	int sum=0;
	int count = 0;
	float avg=0;
	scanf_s("%d%d",&a,&b);
	int small=0;
	int large=0;
	small = a>b?b:a;
	large = a>b?a:b;
	for (int i = small; i <= large; i++) {
		if (i % 3 == 0 || i % 5 == 0) {
			sum+=i;
			count++;
		}
	}
	avg = (double)sum/count;
	printf("sum : %d\navg : %.1f",sum,avg);
	
	return 0;
}