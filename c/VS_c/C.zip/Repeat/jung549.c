#include <stdio.h>

int main(void) {
	int num;
	int sum=0;
	int count=0;
	scanf_s("%d",&num);
	for (int i = 1; i < num; i++) {
		if (i%2==1) {
			if (sum < num) {
				sum+=i;
				count++;
			}
		}
	}
	printf("%d %d",count,sum);

	return 0;
}