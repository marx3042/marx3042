#include <stdio.h>

int main(void) {
	int a,b;
	int small=0;
	int large=0;
	scanf_s("%d%d", &a, &b);
	small = a>b?b:a;
	large = a>b?a:b;
	

	for (int i = small; i <= large; i++) {
		printf("%d ",i);
	}

	return 0;
}