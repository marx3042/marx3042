#include <stdio.h>

int main(void) {

	int a;
	int num3=0;
	int num5=0;

	for (int i = 0; i < 10; i++) {
		scanf_s("%d",&a);

		if (a % 3 == 0 && a % 5 == 0) {
			num3++;
			num5++;
		}
		else if (a % 3 == 0) {
			num3++;
		}
		else if (a % 5 == 0) {
			num5++;
		}
	}

	printf("Multiples of 3 : %d\nMultiples of 5 : %d",num3,num5);

	return 0;
}