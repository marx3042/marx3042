﻿#include <iostream>
#include <windows.h>

/* Linked list node 구조체 */
struct Node {
	int year;								// 가지고 있는 데이터
	Node* link;								// 다음 노드 정보
};

Node* head;									//더미 머리 
Node* tail;									//더미 꼬리 
int size;									//링크드 리스트 크기

void InitList();						    //리스트 초기화
/* 노드추가 */
bool InsertAfter(int value, Node* node);	//특정 노드 뒤 삽입
bool InsertFirst(int value);				//Head뒤 삽입
bool InsertLast(int value);					//size로 마지막 노드를 찾아 노드뒤 삽입
/* 노드 삭제 */
bool DeleteNext(Node* node);				//특정 노드 뒤 삭제
bool DeleteNode(Node* node);				//특정 노드 삭제
bool DeleteFirst();							//head 뒤 삭제
bool DeleteLast();							//size로 마지막 노드를 찾아 해당 노드 삭제
void DeleteAll();							//모든 노드 제거
/* 노드 검색 */
Node* FindNodeWithValue(int value);			//year data 비교하여 노드 찾기
Node* FindNodeWithIndex(int log, int num);			//index 비교하여 노드찾기
/* 노드 작성 도구*/
int GetIndex(int value);					//특정 data 의 index 반환
int GetSize();								//리스트의 크기 반환, 마지막 노드 찾을때
/* 출력 도구*/
void PrintList();							//모든 노드 출력

void gotoxy(int x, int y)
{
	COORD Cur;
	Cur.X = x;
	Cur.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Cur);
}


int main()
{
	InitList();													//List 초기화

	while (true)
	{

		int menu_idx;
		int temp;
		printf("\n");
		PrintList();

		printf("\n");
		printf("1. 노드추가\n");								//메뉴 구성 출력
		printf("2. 노드삭제\n");
		printf("3. 노드검색\n");
		printf("4. 노드출력\n");
		printf("5. 종료\n");
		printf("=======================\n");

		printf("메뉴를 선택하세요?: ");
		temp = scanf_s("%d", &menu_idx);						//메뉴 입력받기

		Node* node;
		int value;
		int num;
		int sub_idx;

		switch (menu_idx)
		{


		case 1: //노드추가
			//InsertAfter(int value, Node * node);			//특정 노드 뒤 삽입
			//InsertFirst(int value);						//Head뒤 삽입
			//InsertLast(int value);						//size로 마지막 노드를 찾아 노드뒤 삽입

			printf("\n노드 추가 위치를 선택하세요\n");		// 삽입노드 와 value입력받기
			printf("    1.맨앞 2.맨뒤 3.Index 지정?: ");
			temp = scanf_s("%d", &sub_idx);
			switch (sub_idx)
			{
			case 1: //맨앞
				printf("\nValue값을 입력하세요?: ");
				temp = scanf_s("%d", &value);
				printf("Insert index: %d\n", 1);
				if (InsertFirst(value) == false)
					printf("노드 삽입에 실패했습니다!!!.:\n"); //삽입 실패
				break;
			case 2: //맨뒤
				printf("\nValue값을 입력하세요?: ");
				temp = scanf_s("%d", &value);
				printf("Insert index: %d\n", GetSize() + 1);
				if (InsertLast(value) == false)
					printf("노드 삽입에 실패했습니다!!!.:\n"); //삽입 실패
				break;
			case 3: //Index 지정
				if (head->link == tail)
				{
					printf("입력된 리스트가 없습니다!!!.\n");
					break;
				}
				printf("\n다음에 삽입할 Index값을 입력하세요[범위:1~%d]?: ", GetSize());
				temp = scanf_s("%d", &num);					//지금은 num만 입력받음
				node = FindNodeWithIndex(0, num - 1);			//index 비교하여 노드찾기, int num
				if (node == tail) 							//범위 밖일때
				{
					printf("범위에 벗어난 Index값을 지정 하였습니다!!!.\n");
					break;
				}

				printf("\nValue값을 입력하세요?: ");
				temp = scanf_s("%d", &value);
				printf("Insert index: %d\n", num + 1);
				if (InsertAfter(value, node) == false)		//특정 노드 뒤 삽입
					printf("노드 삽입에 실패했습니다!!!.\n");


				break;
			default:
				printf("메뉴 범위 값을 벗어났습니다!!!.\n");
				break;
			}

			break;
		case 2: //노드삭제
			//bool DeleteNode(Node * node);				//특정 노드 삭제
			//bool DeleteFirst();						//head 뒤 삭제
			//bool DeleteLast();						//size로 마지막 노드를 찾아 해당 노드 삭제
			//void DeleteAll();							//모든 노드 제거

			printf("\n노드 삭제 위치를 선택하세요\n");			// 삽입노드 입력받기
			printf("    1.맨앞 2.맨뒤 3.Index 지정?: ");
			temp = scanf_s("%d", &sub_idx);
			switch (sub_idx)
			{
			case 1: //맨앞
				if (DeleteFirst() == false)
					printf("노드 삭제에 실패했습니다!!!.:\n");	//삭제 실패
				break;
			case 2: //맨뒤
				if (DeleteLast() == false)
					printf("노드 삭제에 실패했습니다!!!.:\n");	//삭제 실패
				break;
			case 3: //Index 지정
				if (head->link == tail)
				{
					printf("입력된 리스트가 없습니다!!!.\n");
					break;
				}

				printf("\n삭제할 Index값을 입력하세요[범위:1~%d]?: ", GetSize());
				temp = scanf_s("%d", &num);						//지금은 num만 입력받음
				node = FindNodeWithIndex(0, num - 1);				//index 비교하여 노드찾기, int num

				if (node == tail) 								//범위 밖일때
				{
					printf("범위에 벗어난 Index값을 지정 하였습니다!!!.\n");
					break;
				}

				printf("Delete index: %d\n", num);
				if (DeleteNode(node) == false)					//특정 노드 뒤 삽입
					printf("노드 삭제에 실패했습니다!!!.\n");

				break;
			default:
				printf("메뉴 범위 값을 벗어났습니다!!!.\n");
				break;
			}
			break;
		case 3: //노드검색
			printf("\n노드 index를 입력하세요[범위:1~%d]?: ", GetSize());		//value 또는 num 입력받기
			temp = scanf_s("%d", &num);							//지금은 num만 입력받음
			node = FindNodeWithIndex(1, num - 1);					//index 비교하여 노드찾기, int num
			//node= FindNodeWithValue(value);  					//year data 비교하여 노드 찾기, int value
			if (node == tail)										//범위 밖일때
				printf("범위에 벗어난 값으로 노드를 찾지 못했습니다!!!.\n");

			break;
		case 4: //노드출력
			printf("\n");
			PrintList();
			break;
		case 5: //종료
			printf("\n프로그램을 종료합니다!!!.\n");
			exit(1);
			break;
		default:
			printf("메뉴 범위 값을 벗어났습니다!!!.\n");
			break;
		}

		printf("\n");
		system("PAUSE");
		system("cls");
	}
}

void InitList()
{
	head = (Node*)malloc(sizeof(Node));		//머리 메모리 할당
	tail = (Node*)malloc(sizeof(Node));		//꼬리 메모리 할당
	head->link = tail;						//머리 다음은 꼬리
	tail->link = tail;						//꼬리 다음도 꼬리
	size = 0;								//사이즈는 0
}

bool InsertAfter(int value, Node* node)
{
	if (node == tail)						//꼬리 뒤에 삽입 할수 없다.
		return false;

	Node* newNode = (Node*)malloc(sizeof(Node));	//메모리 할당
	newNode->year = value;					//값을 넣어준다
	newNode->link = node->link;				//특정노드가 가르키던 노드를 내가 대신 가르키고
	node->link = newNode;					//특정노드가 나를 가르키게 한다.
	++size;									//크기를 하나 늘려준다.
	printf("Insert value: %d \n", newNode->year);//메세지 출력
	return true;
}

bool InsertFirst(int value)
{
	return InsertAfter(value, head);        //head 바로뒤 삽입한다.
}

bool InsertLast(int value)                  //head에서 최대 size만큼 건너가서 삭제한다.
{
	if (head->link == tail)					//Node가 한개도 없으면 head 뒤가 마지막이 된다.
		return InsertAfter(value, head);    //head 바로뒤 삽입한다.

	Node* node = FindNodeWithIndex(0, GetSize() - 1);	//head에서 최대 size만큼 건너가서 삭제한다.
	return InsertAfter(value, node);
}
bool DeleteNext(Node* node)
{
	if (node->link == tail)					//꼬리를 지울수 없다.
		return false;

	Node* deleteNode = node->link;			//지울 노드를 기억한다.
	printf("Delete value: %d \n", deleteNode->year);	//메세지 출력
	node->link = deleteNode->link;			//지울 노드가 가르키던 노드를 특정 노드가 가르키게 한다.
	free(deleteNode);						//메모리를 해제해준다(중요)
	--size;									//크기를 줄여준다.
	return true;
}

bool DeleteNode(Node* node)
{
	if (node == head || tail == node)		//머리나 꼬리는 지울수 없다.
		return false;

	Node* preNode = head;					//노드는 이전노드 정보를 가지고 있지 않아서 따로 기억해야한다.
	Node* temp = head->link;				//찾는 노드

	while (temp != tail)					//리스트를 끝까지 돈다.
	{
		if (node == temp)					//지울 노드를 찾았다면
		{
			Node* deleteNode = node;		//지울 노드를 기억한다.
			preNode->link = deleteNode->link;	//이전 노드가 지울 노드의 다음을 가르키게한다.
			printf("Delete value: %d \n", deleteNode->year);
			free(deleteNode);				//지울 노드를 메모리 해제
			--size;							//크기를 줄여준다.
			return true;
		}

		preNode = temp;						//못 찾았으면
		temp = temp->link;					//다음 노드로
	}
	return false;
}

bool DeleteFirst()
{
	printf("Delete index: %d\n", 1);
	return DeleteNext(head);				//head 뒤가 첫번째 node가 됨
}

bool DeleteLast()
{
	Node* node = FindNodeWithIndex(0, GetSize() - 1);	// Size로 node 마지막을 찾는다.
	printf("Delete index: %d\n", GetSize());
	return DeleteNode(node);				//해당 노드를 삭제한다.
}
void DeleteAll()
{
	Node* temp = head->link;				//찾는 노드
	Node* deleteNode;						//지울 노드
	while (temp != tail)					//리스트 끝까지 돈다.
	{
		deleteNode = temp;					//현재 노드를 지울 노드로 지정한다.
		temp = temp->link;					//현재 노드는 다음 노드로 넘어간다.
		free(deleteNode);					//지울 노드를 지워준다.
	}
	size = 0;								//사이즈 초기화
	head->link = tail;						//다 비었으니 head 다음은 tail

	printf("Delete All\n");
}

Node* FindNodeWithValue(int value)
{
	Node* temp = head->link;				//찾는 노드
	while (temp != tail)					//리스트를 끝까지 돈다
	{
		if (temp->year == value)			//특정 값을 가진 노드를 찾았으면
		{
			printf("Find Value year : %d \n", temp->year);
			return temp;					//노드를 반환한다.
		}
		temp = temp->link;					//못 찾았으면 다음 노드로
	}
	return temp;							//끝까지 돌았는데 없으면 꼬리 노드 반환
}

Node* FindNodeWithIndex(int log, int num)
{
	if (num < 0 || num >= size)				//크기에 벗어나 있으면 꼬리반환
		return tail;

	Node* temp = head->link;				//head next 가 index 0 노드이다
	for (int i = 0; i < num; ++i)			//반복문을 돌아서
		temp = temp->link;					//num 번째 node를 찾는다.

	if (log == 1)
		printf("Find index : %d Value : %d \n", num + 1, temp->year);
	return temp;
}

int GetIndex(int value)
{
	int index = 0;
	Node* temp = head->link;
	while (temp != tail)
	{
		if (temp->year == value)
		{
			printf("Value : %d index : %d \n", value, index);
			return index;
		}
		++index;
		temp = temp->link;
	}

	return -1;
}

int GetSize()
{
	return size;
}

void PrintList()
{
	int n = 1;
	Node* temp = head->link;				//찾는 노드

	printf("Linked list TABLE\n");				//메세지 출력
	printf("-----------------------\n");
	while (temp != tail)					//리스트 끝까지 돈다.
	{
		printf("%d: %d \n", n, temp->year);	//메세지 출력
		temp = temp->link;					//다음 노드로
		n++;
	}
	printf("-----------------------\n");
	printf("size : %d \n", size);			//크기도 출력
}