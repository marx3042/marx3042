#include <stdio.h>

void Print(int a, int b) {
	int x, y;

	x = a < b ? b : a;
	y = a < b ? a : b;
	
	for (int i = y; i <= x; i++) {
		printf("== %ddan ==\n",i);
		for (int j = 1; j <= 9; j++) {
			printf("%d * %d =%3d\n",i,j,i*j);
		}
		printf("\n");
	}

}

int main(void) {
	int a, b;
	scanf_s("%d%d", &a, &b);

	Print(a, b);

	return 0;
}