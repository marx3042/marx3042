#include <stdio.h>

int Print(int a,int b,int c) {
	int num;
	num = a>b?a:b;
	num = c>num?c:num;
	return num;
}

int main(void) {
	int a,b,c;
	scanf_s("%d%d%d", &a,&b,&c);
	printf("%d",Print(a, b, c));
	return 0;
}