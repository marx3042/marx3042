#include <stdio.h>

void Print(int a) {
	int num;
	
	for (int i = 1; i <= a; i++) {
		num=i;
		for (int j = 1; j <= a; j++) {
			printf("%d ",num*j);
		}
		
		printf("\n");
	}
	
}

int main(void) {
	int a;
	scanf_s("%d", &a);
	Print(a);

	return 0;
}