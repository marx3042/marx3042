#include <stdio.h>

void Print() {
	printf("@@@@@@@@@@\n");
}

int main(void) {
	printf("first\n");
	Print();
	printf("second\n");
	Print();
	printf("third\n");
	Print();

	return 0;
}