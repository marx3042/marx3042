#include <stdio.h>



int main(void) {
	int arNum[3][3];
	int sum;
	int final_sum=0;
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < 3; j++) {
			scanf_s("%d",&arNum[i][j]);
		}
	}
	for (int i = 0; i < 3; i++) {
		sum =0;
		for (int j = 0; j < 3; j++) {
			printf("%d ",arNum[i][j]);
			sum+=arNum[i][j];
		}
		final_sum+=sum;
		printf("%d\n",sum);
	}
	for (int i = 0; i < 3; i++) {
		sum = 0;
		for (int j = 0; j < 3; j++) {
			sum += arNum[j][i];
		}
		printf("%d ", sum);
	}
	printf("%d",final_sum);
	
	return 0;
}