#include <stdio.h>

void Print(int a, int b) {
	int x,y;

	x = a<b?b:a;
	y = a<b?a:b;
	if (a > b) {
		printf("%d %d", x / 2, y * 2);
	}
	else {
		printf("%d %d", y * 2, x / 2);
	}
	
	
}

int main(void) {
	int a,b;
	scanf_s("%d%d", &a, &b);

	Print(a,b);

	return 0;
}