#include <stdio.h>

void Print(int a) {
	for (int i = 0; i < a; i++) {
		printf("~!@#$^&*()_+|\n");
	}
}

int main(void) {
	int a;
	scanf("%d",&a);
	Print(a);
	return 0;
}