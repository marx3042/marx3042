#include <stdio.h>

void Print(int a, char b, int c) {
	if (b == '+') {
		printf("%d + %d = %d",a,c,a+c);
	}
	else if (b == '-') {
		printf("%d - %d = %d", a, c, a - c);
	}
	else if (b == '*') {
		printf("%d * %d = %d", a, c, a * c);
	}
	else if (b == '/') {
		printf("%d / %d = %d", a, c, a / c);
	}
	else {
		printf("%d %c %d = %d", a, b, c, 0);
	}
}

int main(void) {
	int a;
	char b;
	int c;
	scanf_s("%d", &a);
	scanf_s(" %c", &b);
	scanf_s("%d", &c);
	Print(a,b,c);

	return 0;
}