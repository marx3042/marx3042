#include <stdio.h>

int Print(int a, int b) {
	int num=1;
	for (int i = 0; i < b; i++) {
		num*=a;
	}

	return num;
}

int main(void) {
	int a, b, c;
	scanf_s("%d%d", &a, &b);
	printf("%d", Print(a, b));
	return 0;
}