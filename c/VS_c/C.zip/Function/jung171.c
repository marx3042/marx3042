#include <stdio.h>

void Print(int a) {
	int sum=0;
	for (int i = 1; i <= a; i++) {
		sum+=i;
	}
	printf("%d",sum);
}

int main(void) {
	int a;
	scanf_s("%d",&a);
	Print(a);

	return 0;
}