#include <stdio.h>

void Print(int a, char b, int c) {
	int num = 0;

	if (b == '+') {
		num = a+b;
	}
	else if (b == '-') {
		num = a-b;
	}
	else if (b == '*') {
		num = a*b;
	}
	else if (b=='/') {
		num = a/b;
	}
	else {
		num=0;
	}
	printf("%d %c %d = %d", a, b, c, num);

}

int main(void) {
	int a;
	char b;
	int c;
	scanf_s("%d", &a);
	scanf_s(" %c", &b);
	scanf_s("%d", &c);
	Print(a,b,c);

	return 0;
}