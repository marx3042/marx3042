#include <stdio.h>

void Print(int a) {
	
	printf("%.2f",a*a*3.14);
}

int main(void) {
	int a;
	scanf_s("%d", &a);
	Print(a);
	return 0;
}