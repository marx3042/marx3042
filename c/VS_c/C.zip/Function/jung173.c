#include <stdio.h>

void Print(int a, int b) {
	int x, y;

	x = a < b ? b : a;
	y = a < b ? a : b;

	printf("%d",(x*x)-(y*y));

}

int main(void) {
	int a,b;
	scanf_s("%d%d", &a, &b);
	Print(a,b);

	return 0;
}