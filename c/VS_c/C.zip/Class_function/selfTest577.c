#include <stdio.h>

#define PI 3.14

void twoNumber(int a, int b) {
	int largeNum,smallNum;

	if (a > b) {
		largeNum = a/2;
		smallNum = b*2;
		printf("%d %d", largeNum,smallNum);
	}
	else {
		largeNum = b/2;
		smallNum = a*2;
		printf("%d %d", largeNum, smallNum);
	}
}

int multiplication_table(int smallNum, int largeNum) {
	for (int i = smallNum; i <= largeNum; i++) {
		printf("%d dan\n",i);
		for (int j = 1; j <= 9; j++) {
			printf("%d * %d = %d\n",i,j,i*j);
		}
		printf("\n");
	}
	return smallNum,largeNum;
}

int plusAcculate(int num) {
	int result=0;
	for (int i = 1; i <= num; i++) {
		result+=i;
	}
	printf("%d",result);
	return result;
}

void doubleForNum(int num) {
	int count=1;
	for (int i = 0; i < num; i++) {
		for (int j = 0; j < num; j++) {
			
			printf("%d ",count++);
		}
		printf("\n");
	}
}


void main() {



}