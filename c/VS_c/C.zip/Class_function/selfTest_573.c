#include <stdio.h>

void double_for(int num) {
	int plus=1;
	for (int i = 0; i < num; i++) {
		for (int j = 0; j < num; j++) {
			printf("%d ",plus++);
		}
		printf("\n");
	}
}

void main() {

	int inputNum;
	
	scanf_s("%d",&inputNum);
	double_for(inputNum);

}