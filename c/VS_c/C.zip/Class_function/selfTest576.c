#include <stdio.h>

int calculateNum(int a, char calculate, int b) {
	int result;
	
	if (calculate == '+') {
		result = a+b;
	}
	else if(calculate=='-'){
		result = a-b;
	}
	else if(calculate=='*'){
		result = a*b;
	}
	else if(calculate=='/'){
		result = a/b;
	}
	else {
		result = 0;
	}
	return result;
}

void main() {
	
}