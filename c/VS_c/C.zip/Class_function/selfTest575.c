#include <stdio.h>

int squaredNum(int num1, int num2) {
	int result=1;

	for (int i = 0; i < num2; i++) {
		result *=num1;
	}
	return result;
}
void main(){
	int a,b;
	scanf_s("%d%d",&a,&b);
	printf("%d",squaredNum(a,b));

	}