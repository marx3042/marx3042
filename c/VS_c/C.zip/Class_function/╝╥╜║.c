#include <stdio.h>

int main(void) {

	/*int num;

	scanf_s("%d", &num);
	for (int i = 0; i < num + 2; i += 2) {
		for (int j = 0; j < i; j += 2) {
			printf(" ");
		}
		for (int j = num + 2; j > i; j--) {
			printf("*");
		}
		printf("\n");
	}
	for (int i = 1; i<num+2;i+=2) {
		for (int j = num; j > i; j -= 2) {
			printf(" ");
		}
		for (int j = 0; j < i+2; j++) {
			printf("*");
		}
		printf("\n");
	}*/

	int num;

	scanf_s("%d",&num);
	for (int i = 1; i <= num+2; i+=2) {
		for (int j = num+1; j >= i; j--) {
			printf(" ");
		}
		for (int j = 0; j < i; j ++) {
			printf("*");
		}
		printf("\n");
	}


	return 0;
}