#include<stdio.h>

void print_ten_times(char name) {
	for (int i = 0; i < 10; i++) {
		printf("%c",name);
	}
}

int pow_function(int num, int num2) {
	int result = num*num2;
	return result;
}

void char_print_three(int num) {
	for (int i = 0; i < num; i++) {
		printf("~!@#$^&*()_+|");
		printf("\n");
	}
	
}
void succle(int r) {
	double result = (double)r*r*3.14;
	printf("%.2f",result);
	
}

void main() {
	
	int	r;
	scanf_s("%d",&r);
	succle(r);
	
}