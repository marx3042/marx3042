#pragma warning(disable: 4996)
#include <stdio.h>

int main(void) {

	/*char inputChar;
	int count = 0;
	int countChar[26];

	for (int i = 0; i < 26; i++) {
		countChar[i]=0;
	}
	
	while (1) {
		scanf_s(" %c", &inputChar);
		if (!(65 <= (int)inputChar && (int)inputChar <= 90)) {
			break;
		}
		for (int i = 0; i < 26; i++) {
			if ((int)inputChar - 65 == i) {
				countChar[i]++;
			}
		}
	}

	for (int i = 0; i < 26; i++) {
		if(countChar[i]!=0){
		printf("%c : %d\n",(char)(i+65),countChar[i]);
		}
	}*/

	/*int inputNum;
	int arNum[9];

	for (int i = 0; i < 9; i++) {
		arNum[i]=0;
	}

	while (1) {
		scanf_s("%d",&inputNum);
		if (inputNum == 0) {
			break;
		}
		for (int i = 0; i < 9; i++) {
			if (inputNum / 10 == i) {
				arNum[i]++;
			}
		}
	}
	for (int i = 0; i < 9; i++) {
		if (arNum[i] > 0) {
			printf("%d : %d\n",i,arNum[i]);
		}
	}*/

	/*int arNum[100];

	
	arNum[0] = 100;

	scanf_s("%d", &arNum[1]);
	printf("%d ", arNum[0]);
	printf("%d ", arNum[1]);
	for (int i = 2; i < 100; i++) {
		arNum[i]=arNum[i-2]-arNum[i-1];
		printf("%d ", arNum[i]);
		if (arNum[i] < 0) {
			break;
		}
	}*/

	/*int arNum[15]={5,8,10,6,4,11,20,1,13,2,7,9,14,22,3};
	int first=0;

	for (int i = 0; i < 3; i++) {
		for (int j = first; j < first + 5; j++) {
			printf("%2d   ",arNum[j]);
		}
		printf("\n");
		first += 5;
	}*/

	/*int arNum[8][8];

	printf("%s\n","first array");
	
	for (int i = 0; i < 8; i++) {
		scanf_s("%d",&arNum[i][0]);
	}
	printf("%s\n", "Second array");
	for (int i = 0; i < 8; i++) {
		scanf_s("%d",&arNum[0][i]);
	}
	for (int i = 0; i < 8; i++) {
		arNum[i][i]=arNum[0][i]*arNum[i][0];
		printf("%d ", arNum[i][i]);
		
	}*/

	/*int arNum[4][5],sum[5],length=0,count=0;
	double arAvg[5];
	
	length=sizeof(sum)/sizeof(int);

	for (int i = 0; i < length; i++) {
		sum[i]=0;
		arAvg[i]=0.0;
		for (int j = 0; j < 4; j++) {
			scanf("%d", &arNum[j][i]);
			sum[i]+=arNum[j][i];
		}
		arAvg[i]=sum[i]/(double)4;
		
	}
	for (int i = 0; i < length; i++) {
		if (arAvg[i] >= 80) {
			printf("pass\n");
			count++;
		}
		else {
			printf("fail\n");
		}
	}
	printf("successful : %d",count);*/



	return 0;
}