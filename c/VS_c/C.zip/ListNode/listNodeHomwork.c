#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
	int data;
	struct Node *nextLink;
}Node;

typedef struct List {
	Node *head;
	int number_of_data;
}List;

Node* addNode() {
	Node *new = (Node*)malloc(sizeof(Node));
	new->nextLink = NULL;
	return new;
}

List* fristNode() {
	List *link = (List*)malloc(sizeof(List));
	link->head = addNode();
	link->number_of_data=0;
	return link;
}

void Insert(List *link, int inputNum) {
	Node *newNode = addNode();
	newNode->data = inputNum;
	if (link->head->nextLink == NULL) {
		newNode->nextLink = NULL;
		link->head->nextLink=newNode;
	}
	else {
		newNode->nextLink = NULL;
		link->head->nextLink = newNode;
	}
}

void Remove(List* link, int inputNum) {
	Node *cur = link->head;
	Node *rpos;

	if (link->head->nextLink = NULL) {
		printf("������ �����Ͱ� �����ϴ�.\n");
	}
	else {
		while(cur->nextLink !=NULL){
			if(cur->nextLink->data = inputNum){
				rpos = cur->nextLink;
				cur->nextLink = cur->nextLink->nextLink;
				free(rpos);
				return;
			}
			cur = cur->nextLink;
		}
		if(cur->nextLink = NULL){
			printf("ã�� �����Ͱ� �����ϴ�.\n");
		}
	}
}

void Search(List* link, int num) {
	Node *cur = link->head;
	if (link->head->nextLink = NULL) {
		printf("ã�� �����Ͱ� �����ϴ�.\n");
	}
	else {
		while (cur->data == num) {
			printf("%d",num);
			return;
		}
		cur = cur->nextLink;
	}
	return cur;
}

void Print(List* link) {
	Node *cur;
	if (link->head->nextLink == NULL) {
		printf("�����Ͱ� �����ϴ�.\n");
	}
	else {
		cur = link->head->nextLink;
		while (cur != NULL) {
			printf("%d",cur->data);
			cur=cur->nextLink;
		}
	}
}

void main() {
	int num=20;

	Node *head=malloc(sizeof(Node));

	Insert(head,&num);

	
	Print(head);

}