#include <stdio.h>

int main(void) {
	int a,b;
	int r=0;
	scanf_s("%d%d",&a,&b);
	r=(a++)*(--b);
	printf("%d ",a);
	printf("%d ",b);
	
	printf("%d ",r);
	return 0;
}