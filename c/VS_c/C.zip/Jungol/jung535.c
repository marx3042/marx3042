﻿#include <stdio.h>

int main(void) {

	float num;
	scanf_s("%f",&num);
	
	switch ((int)num) {
	case 4 : 
		printf("scholarship");
		break;
	case 3 : 
		printf("next semester");
		break;
	case 2 : 
		printf("seasonal semester");
		break;
	default:
		printf("retake");
		break;
	}
	return 0;
}