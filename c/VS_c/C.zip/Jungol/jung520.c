#include <stdio.h>

int main(void) {
	int a;
	scanf_s("%d",&a);

	printf("%d\n",a++);
	printf("%d",++a);
	return 0;
}