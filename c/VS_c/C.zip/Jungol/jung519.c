#include <stdio.h>

int main(void) {
	int a,b;
	scanf_s("%d%d",&a,&b);
	printf("%d %d",a+100,b%10);

	return 0;
}