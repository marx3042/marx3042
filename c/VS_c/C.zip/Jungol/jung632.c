#include <stdio.h>

int main(void) {

	int a,b,c;
	int num=0;
	int last=0;
	scanf("%d%d%d",&a,&b,&c);
	num = a>b?b:a;
	last = c>num?num:c;

	printf("%d", last);
	

	return 0;
}